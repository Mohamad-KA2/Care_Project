import cwk4.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Test class for verifying champion entry functionalities in the game.
 * These tests focus on ensuring that champions can be successfully entered into the game.
 */
public class T4ChampionEnteredTest {
    CARE game;

    /**
     * Constructor for the test class.
     */
    public T4ChampionEnteredTest() {
    }

    /**
     * Method to set up class before running any test methods.
     */
    @BeforeClass
    public static void setUpClass() {
    }

    /**
     * Method to tear down class after running all test methods.
     */
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Method to set up test environment before each test method.
     */
    @Before
    public void setUp() {
        game = new Tournament("Olenka");
    }

    /**
     * Method to clean up test environment after each test method.
     */
    @After
    public void tearDown() {
    }

    /**
     * Test method to verify the result when one champion is entered.
     */
    @Test
    public void oneChampionEnteredResult0() {
        int expected = 0;
        int actual = game.enterChampion("Flimsi");
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify if treasury is deducted when one champion is entered.
     */
    @Test
    public void oneChampionEnteredTreasuryDeducted() {
        int expected = 800;
        game.enterChampion("Flimsi"); // Don't store return
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify if one champion is in the team after entering.
     */
    @Test
    public void oneChampionEnteredInTeam() {
        game.enterChampion("Flimsi");
        boolean actual = game.isInViziersTeam("Flimsi");
        assertTrue(actual);
    }

    /**
     * Test method to verify if one champion is not in reserve after entering.
     */
    @Test
    public void oneChampionNotInReserve() {
        game.enterChampion("Flimsi");
        boolean actual = !game.isInReserve("Flimsi");
        assert(actual);
    }

    /**
     * Test method to verify that a champion cannot be entered twice.
     */
    @Test
    public void oneChampionNotEnteredTwice() {
        int expected = 1;
        game.enterChampion("Flimsi");
        int actual = game.enterChampion("Flimsi");
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify if there's not enough money to enter all champions.
     */
    @Test
    public void notEnoughMoney() {
        int expected = 400;
        game.enterChampion("Flimsi");
        game.enterChampion("Ganfrank");
        game.enterChampion("Argon");
        assertEquals(expected, game.getMoney());
    }

    /**
     * Test method to verify the result when there's not enough money to enter all champions.
     */
    @Test
    public void notEnoughMoneyResult2() {
        int expected = 2;
        game.enterChampion("Flimsi");
        game.enterChampion("Ganfrank");
        int actual = game.enterChampion("Argon");
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify that a champion not entered due to insufficient funds is not in the team.
     */
    @Test
    public void notEnoughMoneySoNotInTeam() {
        game.enterChampion("Flimsi");
        game.enterChampion("Ganfrank");
        game.enterChampion("Argon");
        boolean actual = !game.isInViziersTeam("Argon");
        assertTrue(actual);
    }

    /**
     * Test method to verify that a champion not entered due to insufficient funds stays in reserve.
     */
    @Test
    public void notEnoughMoneySoStaysInReserve() {
        game.enterChampion("Flimsi");
        game.enterChampion("Ganfrank");
        game.enterChampion("Argon");
        boolean actual = (game.getReserve()).contains("Argon");
        assertTrue(actual);
    }

    /**
     * Test method to verify the result when trying to enter a non-existing champion.
     */
    @Test
    public void noSuchChampionEntered() {
        int expected = -1;
        int actual = game.enterChampion("Boggle");
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify that treasury remains unchanged when trying to enter a non-existing champion.
     */
    @Test
    public void noSuchChampionEnteredNoDeduction() {
        int expected = 1000;
        game.enterChampion("Boggle");
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify that a champion not entered due to insufficient funds stays in reserve.
     */
    @Test
    public void notEnoughMoneySoStaysInreserve() {
        game.enterChampion("Flimsi");
        game.enterChampion("Ganfrank");
        game.enterChampion("Argon");
        boolean actual = (game.getReserve()).contains("Argon");
        assertTrue(actual);
    }
}
