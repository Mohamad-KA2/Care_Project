import cwk4.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Test class for verifying the meeting of challenges by champions in the game.
 * These tests focus on different scenarios when champions meet challenges.
 */
public class T5MeetChallengeTest {
    CARE game;

    /**
     * Constructor for the test class.
     */
    public T5MeetChallengeTest() {
    }

    /**
     * Method to set up class before running any test methods.
     */
    @BeforeClass
    public static void setUpClass() {
    }

    /**
     * Method to tear down class after running all test methods.
     */
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Method to set up test environment before each test method.
     */
    @Before
    public void setUp() {
        game = new Tournament("Jean");
    }

    /**
     * Method to clean up test environment after each test method.
     */
    @After
    public void tearDown() {
    }

    // Wizards

    /**
     * Test method to verify a wizard wins when facing a magic challenge.
     */
    @Test
    public void wizardFacingMagicWins() {
        int expected = 0;
        game.enterChampion("Ganfrank");
        int actual = game.meetChallenge(1);
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the treasury is correctly updated when a wizard wins against magic.
     */
    @Test
    public void wizardFacingMagicWinsMoney() {
        int expected = 1000 - 400 + 100;
        game.enterChampion("Ganfrank");
        game.meetChallenge(1);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify a wizard loses on skill when facing a magic challenge.
     */
    @Test
    public void wizardFacingMagicLosesOnSkill() {
        int expected = 1;
        game.enterChampion("Neon");
        int actual = game.meetChallenge(1);
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the treasury is correctly updated when a wizard loses on skill against magic.
     */
    @Test
    public void wizardFacingMagicLosesOnSkillMoneyDeducted() {
        int expected = 1000 - 300 - 100;
        game.enterChampion("Neon");
        game.meetChallenge(1);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify a disqualified wizard is marked as disqualified.
     */
    @Test
    public void wizardLosingIsDisqualified() {
        game.enterChampion("Neon");
        game.meetChallenge(1);
        boolean actual = game.getChampionDetails("Neon").toLowerCase().contains("disqualified");
        assertTrue(actual);
    }

    /**
     * Test method to verify a disqualified champion cannot be withdrawn.
     */
    @Test
    public void cantWithdrawDead() {
        int expected = 1;
        game.enterChampion("Neon");
        game.meetChallenge(1);
        int actual = game.retireChampion("Neon");
        assertEquals(actual, expected);
    }

    /**
     * Test method to verify a disqualified champion's withdrawal doesn't affect the treasury.
     */
    @Test
    public void cantWithdrawDisqualifiedMoneyNotAffected() {
        int expected = 1000 - 300 - 100;
        game.enterChampion("Neon");
        game.meetChallenge(1);
        game.retireChampion("Neon");
        int actual = game.getMoney();
        assertEquals(actual, expected);
    }

    /**
     * Test method to verify a wizard facing a non-existing magic challenge returns -1.
     */
    @Test
    public void wizardFacingNoSuchMagic() {
        int expected = -1;
        game.enterChampion("Ganfrank");
        int actual = game.meetChallenge(14);
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify a wizard wins when facing a fight challenge.
     */
    @Test
    public void wizardFacingFightWins() {
        int expected = 0;
        game.enterChampion("Ganfrank");
        int actual = game.meetChallenge(2);
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the treasury is correctly updated when a wizard wins against a fight challenge.
     */
    @Test
    public void wizardFacingFightWinsMoneyAdded() {
        int expected = 1000 - 400 + 120;
        game.enterChampion("Ganfrank");
        game.meetChallenge(2);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify a wizard loses on skill when facing a fight challenge.
     */
    @Test
    public void wizardFacingFightLosesOnSkill() {
        int expected = 1;
        game.enterChampion("Neon");
        int actual = game.meetChallenge(2);
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the treasury is correctly updated when a wizard loses on skill against a fight challenge.
     */
    @Test
    public void wizardFacingFightLosesOnSkillMoneyDeducted() {
        int expected = 1000 - 300 - 100;
        game.enterChampion("Neon");
        game.meetChallenge(1);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify a wizard wins when facing a mystery challenge.
     */
    @Test
    public void wizardFacingMysteryWins() {
        int expected = 0;
        game.enterChampion("Ganfrank");
        int actual = game.meetChallenge(3);
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the treasury is correctly updated when a wizard wins against a mystery challenge.
     */
    @Test
    public void wizardFacingMysteryWinsMoneyAdded() {
        int expected = 1000 - 400 + 150;
        game.enterChampion("Ganfrank");
        game.meetChallenge(3);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify a wizard loses on skill when facing a mystery challenge.
     */
    @Test
    public void wizardFacingMysteryLosesOnSkill() {
        int expected = 1;
        game.enterChampion("Neon");
        int actual = game.meetChallenge(3);
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the treasury is correctly updated when a wizard loses on skill against a mystery challenge.
     */
    @Test
    public void wizardFacingMysteryLosesOnSkillMoneyDeducted() {
        int expected = 1000 - 300 - 150;
        game.enterChampion("Neon");
        game.meetChallenge(3);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    // Dragon

    /**
     * Test method to verify a dragon cannot face a magic challenge.
     */
    @Test
    public void dragonFacingMagicNotAllowed() {
        int expected = 2;
        game.enterChampion("Xenon");
        game.meetChallenge(1);
        int actual = game.meetChallenge(1);
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the treasury is correctly updated when a dragon attempts to face a magic challenge.
     */
    @Test
    public void dragonFacingMagicNotAllowedMoneyDeducted() {
        int expected = 400;
        game.enterChampion("Xenon");
        game.meetChallenge(1);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify a dragon wins when facing a fight challenge.
     */
    @Test
    public void dragonFacingFightAllowedWins() {
        int expected = 0;
        game.enterChampion("Xenon");
        int actual = game.meetChallenge(2);
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the treasury is correctly updated when a dragon wins against a fight challenge.
     */
    @Test
    public void dragonFacingFightAllowedWinsMoneyAdded() {
        int expected = 620;
        game.enterChampion("Xenon");
        game.meetChallenge(2);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify a dragon loses on skill when facing a fight challenge.
     */
    @Test
    public void dragonFacingFightAllowedLosesOnSkill() {
        int expected = 1;
        game.enterChampion("Drabina");
        int actual = game.meetChallenge(8);
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the treasury is correctly updated when a dragon loses on skill against a fight challenge.
     */
    @Test
    public void dragonFacingFightAllowedLosesMoneyDeducted() {
        int expected = 330;
        game.enterChampion("Drabina");
        game.meetChallenge(8);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify a dragon cannot face a mystery challenge.
     */
    @Test
    public void dragonFacingMysteryNotAllowed() {
        int expected = 2;
        game.enterChampion("Drabina");
        //game.meetChallenge(3);
        int actual = game.meetChallenge(3);
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the treasury is correctly updated when a dragon attempts to face a mystery challenge.
     */
    @Test
    public void dragonFacingMysteryAllowedMoneyAdded() {
        int expected = 650;
        game.enterChampion("Golum");
        game.meetChallenge(3);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    // Warriors

    /**
     * Test method to verify a warrior cannot face a magic challenge.
     */
    @Test
    public void warriorFacingMagicNotAllowed() {
        int expected = 2;
        game.enterChampion("Argon");
        game.meetChallenge(1);
        int actual = game.meetChallenge(1);
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the treasury is correctly updated when a warrior attempts to face a magic challenge.
     */
    @Test
    public void warriorFacingMagicNotAllowedMoneyDeducted() {
        int expected = 0;
        game.enterChampion("Argon");
        game.meetChallenge(1);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify a warrior wins when facing a fight challenge.
     */
    @Test
    public void warriorFacingFightAllowedWins() {
        int expected = 0;
        game.enterChampion("Argon");
        int actual = game.meetChallenge(2);
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the treasury is correctly updated when a warrior wins against a fight challenge.
     */
    @Test
    public void warriorFacingFightAllowedWinsMoneyAdded() {
        int expected = 220;
        game.enterChampion("Argon");
        game.meetChallenge(2);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify a warrior loses on skill when facing a fight challenge.
     */
    @Test
    public void warriorFacingFightAllowedLosesOnSkill() {
        int expected = 1;
        game.enterChampion("Flimsi");
        int actual = game.meetChallenge(2);
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the treasury is correctly updated when a warrior loses on skill against a fight challenge.
     */
    @Test
    public void warriorFacingFightAllowedLosesMoneyDeducted() {
        int expected = 680;
        game.enterChampion("Flimsi");
        game.meetChallenge(2);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify a warrior cannot face a mystery challenge.
     */
    @Test
    public void warriorFacingMysteryNotAllowed() {
        int expected = 2;
        game.enterChampion("Argon");
        game.meetChallenge(3);
        int actual = game.meetChallenge(1);
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the treasury is correctly updated when a warrior attempts to face a mystery challenge.
     */
    @Test
    public void warriorFacingMysteryNotAllowedMoneyDeducted() {
        int expected = -50;
        game.enterChampion("Argon");
        game.meetChallenge(3);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
}
