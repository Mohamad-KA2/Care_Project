import cwk4.CARE;
import cwk4.Tournament;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Test class for verifying different challenge sequences in the game.
 * These tests focus on various scenarios involving champion actions during challenges.
 */
public class T7ChallengeSequences {
    CARE game;

    /**
     * Constructor for the test class.
     */
    public T7ChallengeSequences() {
    }

    /**
     * Method to set up class before running any test methods.
     */
    @BeforeClass
    public static void setUpClass() {
    }

    /**
     * Method to tear down class after running all test methods.
     */
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Method to set up test environment before each test method.
     */
    @Before
    public void setUp() {
        game = new Tournament("Jean");
    }

    /**
     * Method to clean up test environment after each test method.
     */
    @After
    public void tearDown() {
    }

    // Test methods

    /**
     * Test method to verify a dead warrior is used again, resulting in failure (2).
     */
    @Test
    public void warriorDeadUsedAgain() {
        int expected = 2;
        game.enterChampion("Flimsi");
        game.meetChallenge(2);  //should be dead
        int actual = game.meetChallenge(2); //re-used ?
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the money deduction when a dead warrior is used again.
     */
    @Test
    public void warriorDeadUsedAgainMoney() {
        int expected = 1000 - 200 - 120 - 120;
        game.enterChampion("Flimsi");
        game.meetChallenge(2);  //should be dead
        game.meetChallenge(2); //re-used ?
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify a warrior withdrawn before fight, resulting in failure (2).
     */
    @Test
    public void warriorWithdrawnBeforeFight() {
        int expected = 2;
        game.enterChampion("Argon");
        game.retireChampion("Argon");
        int actual = game.meetChallenge(2); //used ?
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the money deduction when a warrior is withdrawn before fight.
     */
    @Test
    public void warriorWithdrawnBeforeFightMoney() {
        int expected = 1000 - 900 + 450 - 120;
        game.enterChampion("Argon");
        game.retireChampion("Argon");
        game.meetChallenge(2);  //not available
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify defeat achieved scenario.
     */
    @Test
    public void defeatAchieved() {
        int expected = 3;
        game.enterChampion("Rudolf");
        game.enterChampion("Flimsi");
        game.meetChallenge(8);  //lose
        game.meetChallenge(8);  //lose
        game.meetChallenge(8);  //no one left
        int actual = game.meetChallenge(8);  //no one left
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the money calculation when defeat is achieved with withdrawal.
     */
    @Test
    public void defeatWithWithdrawalMoney() {
        int expected = 1000 - 400 - 200 - 170 + 100 - 170 - 170;
        game.enterChampion("Rudolf");
        game.enterChampion("Flimsi");
        game.meetChallenge(8);  //lose
        game.retireChampion("Flimsi");
        game.meetChallenge(8);  //no one left
        game.meetChallenge(8);  //no one left
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify defeat not achieved scenario.
     */
    @Test
    public void defeatNotAchieved() {
        int expected = 2;
        game.enterChampion("Drabina");
        game.enterChampion("Flimsi");
        game.meetChallenge(4);  //lose as no one available
        game.meetChallenge(4);  //lose as no one available
        int actual = game.meetChallenge(4);  //lose as no one available
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the money calculation when defeat is not achieved.
     */
    @Test
    public void defeatNotAchievedMoney() {
        int expected = 1000 - 500 - 200 - 200 - 200 - 200;
        game.enterChampion("Drabina");
        game.enterChampion("Flimsi");
        game.meetChallenge(4);  //lose as no one available
        game.meetChallenge(4);  //lose as no one available
        game.meetChallenge(4);  //lose as no one available
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify defeat achieved after withdrawal scenario.
     */
    @Test
    public void defeatAchievedAfterWithdraw() {
        int expected = 3;
        game.enterChampion("Drabina");
        game.enterChampion("Flimsi");
        game.meetChallenge(4);  //lose as no one available
        game.meetChallenge(4);  //lose as no one available
        game.retireChampion("Drabina");
        game.retireChampion("Flimsi"); //no one in Team
        game.meetChallenge(4);  //lose as no one available
        int actual = game.meetChallenge(4);  //lose as no one available
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify the money calculation when defeat is achieved after withdrawal.
     */
    @Test
    public void defeatAchievedAfterWithdrawMoney() {
        int expected = 1000 - 500 - 200 - 200 - 200 + 250 + 100 - 200 - 200;
        game.enterChampion("Drabina");
        game.enterChampion("Flimsi");
        game.meetChallenge(4);  //lose as no one available
        game.meetChallenge(4);  //lose as no one available
        game.retireChampion("Drabina");
        game.retireChampion("Flimsi"); //no one in Team
        game.meetChallenge(4);  //lose as no one available
        game.meetChallenge(4);  //lose as no one available
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify defeat not achieved with only dragons.
     */
    @Test
    public void defeatNotAchievedOnlyDragons() {
        int expected = 1000 - 500 - 500 + 150 + 120;
        game.enterChampion("Drabina");
        game.enterChampion("Golum");
        game.meetChallenge(3);
        game.meetChallenge(2);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify defeat achieved when no suitable champions are available.
     */
    @Test
    public void defeatAchievedNoSuitableChampions() {
        int expected = 1000 - 150 - 200 - 300 - 200 - 150;
        game.enterChampion("Flimsi");
        game.enterChampion("Elblond");
        game.enterChampion("Neon");
        game.meetChallenge(7);
        game.meetChallenge(3);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
}
