/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import cwk4.*;

import java.util.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author comqaam
 */
/**
 * Test class for initializing the game state.
 */
public class T1InitializationTest {
    CARE game;

    /**
     * Constructor for the test class.
     */
    public T1InitializationTest() {
    }

    /**
     * Method to set up class before running any test methods.
     */
    @BeforeClass
    public static void setUpClass() {
    }

    /**
     * Method to tear down class after running all test methods.
     */
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Method to set up test environment before each test method.
     */
    @Before
    public void setUp() {
        game = new Tournament("Olek");
    }

    /**
     * Method to clean up test environment after each test method.
     */
    @After
    public void tearDown() {
    }

    /**
     * Method to check if a given text contains specific substrings.
     *
     * @param text The text to be checked.
     * @param s    An array of strings to be checked for presence in the text.
     * @return True if all strings are found in the text, false otherwise.
     */
    private boolean containsText(String text, String[] s) {
        boolean check = true;
        for (int i = 0; i < s.length; i++)
            check = check && text.contains(s[i]);
        return check;
    }

    /**
     * Test method to verify if the game is correctly initialized.
     */
    @Test
    public void gameCorrectlyInitialised() {
        String result = game.toString();
        String[] xx = {"Olek", "1000", "Is OK", "No champions"};
        boolean actual = containsText(result, xx);
        assertTrue(actual);
    }

    /**
     * Test method to verify the initial treasury amount.
     */
    @Test
    public void treasuryTest() {
        int expected = 1000;
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify if the game is not initially defeated.
     */
    @Test
    public void defeatedTest() {
        boolean actual = game.isDefeated();
        assertFalse(actual);
    }

    /**
     * Test method to verify that the team is empty at the start of the game.
     */
    @Test
    public void checkTeamEmptyAtStart() {
        boolean result = true;
        List<String> champs = new ArrayList<String>(Arrays.asList("Ganfrank", "Rudolf",
                "Elblond", "Flimsi", "Drabina", "Golum", "Argon", "Neon", "Xenon"));

        for (String chmp : champs) {
            result = result && !game.isInViziersTeam(chmp);
        }
        assertTrue(result);
    }
}
