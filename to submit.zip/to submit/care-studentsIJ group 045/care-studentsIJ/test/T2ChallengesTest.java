import cwk4.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Test class for validating challenges in the game.
 * These tests focus on verifying the presence and correctness of challenges in the game.
 * Note: Testing Strings might not cover all edge cases, such as capital/lower case variations or spaces.
 * Utilizing trim() and toLowerCase() could improve string comparison.
 * Additionally, the tests do not validate the order of String components.
 */
public class T2ChallengesTest {
    CARE game;

    /**
     * Constructor for the test class.
     */
    public T2ChallengesTest() {
    }

    /**
     * Method to set up class before running any test methods.
     */
    @BeforeClass
    public static void setUpClass() {
    }

    /**
     * Method to tear down class after running all test methods.
     */
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Method to set up test environment before each test method.
     */
    @Before
    public void setUp() {
        game = new Tournament("Olenka");
    }

    /**
     * Method to clean up test environment after each test method.
     */
    @After
    public void tearDown() {
    }

    /**
     * Method to check if a given text contains specific substrings.
     *
     * @param text The text to be checked.
     * @param s    An array of strings to be checked for presence in the text.
     * @return True if all strings are found in the text, false otherwise.
     */
    private boolean containsText(String text, String[] s) {
        boolean check = true;
        for (int i = 0; i < s.length; i++)
            check = check && text.contains(s[i]);
        return check;
    }

    /**
     * Test method to verify if the Magic challenge is correctly displayed.
     */
    @Test
    public void challengeMagicDisplayed() {
        boolean actual = false;
        String result = game.getAllChallenges();
        String[] xx = {"1", "Magic", "Borg", "3", "100"};
        actual = containsText(result, xx);
        assertTrue(actual);
    }

    /**
     * Test method to verify if the Fight challenge is correctly displayed.
     */
    @Test
    public void challengeFightDisplayed() {
        boolean actual = false;
        String result = game.getAllChallenges();
        String[] xx = {"2", "Fight", "Huns", "3", "120"};
        actual = containsText(result, xx);
        assertTrue(actual);
    }

    /**
     * Test method to verify if the Mystery challenge is correctly displayed.
     */
    @Test
    public void challengeMysteryDisplayed() {
        boolean actual = false;
        String result = game.getAllChallenges();
        String[] xx = {"3", "Mystery", "Ferengi", "3", "150"};
        actual = containsText(result, xx);
        assertTrue(actual);
    }

    // You can add more but is it worth it ?

    /**
     * Test method to verify if the challenge ID falls within the mid-range.
     */
    @Test
    public void isChallengeTestMidRange() {
        boolean result = game.isChallenge(3);
        assertTrue(result);
    }

    /**
     * Test method to verify if the challenge ID falls within the start range.
     */
    @Test
    public void isChallengeTestStartRange() {
        boolean result = game.isChallenge(1);
        assertTrue(result);
    }

    /**
     * Test method to verify if the challenge ID falls within the end range.
     */
    @Test
    public void isChallengeTestEndRange() {
        boolean result = game.isChallenge(9);
        assertTrue(result);
    }

    /**
     * Test method to verify if the challenge ID falls beyond the end range.
     */
    @Test
    public void isChallengeTestOverEndRange() {
        boolean result = game.isChallenge(14);
        assertFalse(result);
    }

    /**
     * Test method to verify if the challenge ID falls before the start range.
     */
    @Test
    public void isChallengeTestUnderStartRange() {
        boolean result = game.isChallenge(0);
        assertFalse(result);
    }

    /**
     * Test method to verify if the correct challenge information is retrieved.
     */
    @Test
    public void getChallengeTest() {
        String result = game.getChallenge(3);
        boolean actual = result.contains("Mystery");//&& result.contains("Ferengi");
        assertTrue(actual);
    }
}
