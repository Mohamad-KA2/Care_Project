import cwk4.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Test class for verifying the retirement of champions in the game.
 * These tests focus on different scenarios when champions are retired.
 */
public class T6ChampionRetiredTest {
    CARE game;

    /**
     * Constructor for the test class.
     */
    public T6ChampionRetiredTest() {
    }

    /**
     * Method to set up class before running any test methods.
     */
    @BeforeClass
    public static void setUpClass() {
    }

    /**
     * Method to tear down class after running all test methods.
     */
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Method to set up test environment before each test method.
     */
    @Before
    public void setUp() {
        game = new Tournament("OO");
        game.enterChampion("Ganfrank");
        game.enterChampion("Elblond");
        game.enterChampion("Neon");
    }

    /**
     * Method to clean up test environment after each test method.
     */
    @After
    public void tearDown() {
    }

    // Test methods

    /**
     * Test method to verify retiring a champion results in success (0).
     */
    @Test
    public void retireChampionTestResult0(){
        int expected = 0;
        int actual = game.retireChampion("Neon");
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify retiring a champion adds money correctly to the treasury.
     */
    @Test
    public void retireChampionTestMoneyAdded(){
        int expected = 1000 - (400 + 150 + 300) + 300 / 2;
        game.retireChampion("Neon");
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify a retired champion is no longer in the team.
     */
    @Test
    public void retireChampionNotInTeam(){
        game.retireChampion("Neon");
        boolean actual = game.isInViziersTeam("Neon");
        assertFalse(actual);
    }

    /**
     * Test method to verify a retired champion is moved to the reserve.
     */
    @Test
    public void retireChampionInReserve(){
        game.retireChampion("Flimsi");
        String list = game.getReserve();
        boolean actual = list.contains("Flimsi");
        assertTrue(actual);
    }

    /**
     * Test method to verify retiring a non-existing champion results in failure (2).
     */
    @Test
    public void retireChampionTestResult2(){
        int expected = 2;
        int actual = game.retireChampion("Flimsi");
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify retiring a non-existing champion does not affect the treasury.
     */
    @Test
    public void retireChampionTestResult2Money(){
        int expected = 150;
        game.retireChampion("Flimsi");
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify retiring a non-existing champion returns -1.
     */
    @Test
    public void retireNoSuchChampionTestResult2(){
        int expected = -1;
        int actual = game.retireChampion("Boggle");
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify retiring a non-existing champion does not affect the treasury.
     */
    @Test
    public void retireNoSuchChampionTestMoney(){
        int expected = 150;
        game.retireChampion("Boggle");
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /**
     * Test method to verify a retired non-existing champion is not in the team.
     */
    @Test
    public void retiredNoSuchChampionNotInTeam(){
        game.retireChampion("Boggle");
        boolean actual = game.isInViziersTeam("Boggle");
        assertFalse(actual);
    }

    /**
     * Test method to verify a retired non-existing champion is not in the reserve.
     */
    @Test
    public void retiredNoSuchChampionNotInReserve(){
        game.retireChampion("Boggle");
        String list = game.getReserve();
        boolean actual = list.contains("Boggle");
        assertFalse(actual);
    }

    /**
     * Test method to verify retiring a dead champion returns failure (1).
     */
    @Test
    public void retireDeadChampion() {
        int expected = 1;
        game.retireChampion("Ganfrank");
        game.meetChallenge(7);
        int actual = game.retireChampion("Neon");
        assertEquals(expected, actual);
    }
}
