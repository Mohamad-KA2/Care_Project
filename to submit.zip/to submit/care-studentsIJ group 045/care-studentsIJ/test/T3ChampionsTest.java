import cwk4.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Test class for validating champion-related functionalities in the game.
 * These tests focus on verifying champion presence, details, and display in the game.
 * Note: Testing Strings might not cover all edge cases, such as capital/lower case variations.
 * Utilizing toLowerCase() could improve string comparison.
 */
public class T3ChampionsTest {
    CARE game;

    /**
     * Constructor for the test class.
     */
    public T3ChampionsTest() {
    }

    /**
     * Method to set up class before running any test methods.
     */
    @BeforeClass
    public static void setUpClass() {
    }

    /**
     * Method to tear down class after running all test methods.
     */
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Method to set up test environment before each test method.
     */
    @Before
    public void setUp() {
        game = new Tournament("Ola");
    }

    /**
     * Method to clean up test environment after each test method.
     */
    @After
    public void tearDown() {
    }

    /**
     * Method to check if a given text contains specific substrings.
     *
     * @param text The text to be checked.
     * @param str  An array of strings to be checked for presence in the text.
     * @return True if all strings are found in the text, false otherwise.
     */
    private boolean containsText(String text, String[] str) {
        boolean result = true;
        for (String temp : str) {
            result = result && (text.toLowerCase()).contains(temp.toLowerCase());
        }
        return result;
    }

    /**
     * Test method to verify if a champion is in reserve.
     */
    @Test
    public void isChampionTest() {
        boolean actual = game.isInReserve("Flimsi");
        assertTrue(actual);
    }

    /**
     * Test method to verify if champion details are retrieved correctly.
     */
    @Test
    public void getChampionDetailsTest() {
        String details = game.getChampionDetails("Argon");
        String[] xx = {"Argon", "9", "900", "mace", "Warrior"};
        boolean actual = containsText(details, xx);
        assertTrue(actual);
    }

    /**
     * Test method to verify if Ganfrank is displayed in reserve.
     */
    @Test
    public void championInReserveGanfrankDisplayed() {
        String result = game.getReserve();
        String[] xx = {"Ganfrank", "true", "7", "400", "transmutation", "Wizard"};
        boolean actual = containsText(result, xx);
        assertTrue(actual);
    }

    /**
     * Test method to verify if Rudolf is displayed in reserve.
     */
    @Test
    public void ChampionInReserveRudolfDisplayed() {
        String result = game.getReserve();
        String[] xx = {"Rudolf", "true", "6", "400", "invisibility", "Wizard"};
        boolean actual = containsText(result, xx);
        assertTrue(actual);
    }

    /**
     * Test method to verify if Elblond is displayed in reserve.
     */
    @Test
    public void ChampionInReserveElblondDisplayed() {
        String result = game.getReserve();
        String[] xx = {"Elblond", "1", "150", "sword", "Warrior"};
        boolean actual = containsText(result, xx);
        assertTrue(actual);
    }

    /**
     * Test method to verify if Drabina is displayed in reserve.
     */
    @Test
    public void ChampionInReserveDrabinaDisplayed() {
        String result = game.getReserve();
        String[] xx = {"Drabina", "7", "500", "false", "Dragon"};
        boolean actual = containsText(result, xx);
        assertTrue(actual);
    }

    /**
     * Test method to verify if Golum is displayed in reserve.
     */
    @Test
    public void ChampionInReserveGolumDisplayed() {
        String result = game.getReserve();
        String[] xx = {"Golum", "7", "500", "true"};
        boolean actual = containsText(result, xx);
        assertTrue(actual);
    }

    /**
     * Test method to verify if Neon is displayed in reserve.
     */
    @Test
    public void ChampionInReserveNeonDisplayed() {
        String result = game.getReserve();
        String[] xx = {"Neon", "2", "false", "300", "translocation", "Wizard"};
        boolean actual = containsText(result, xx);
        assertTrue(actual);
    }

    /**
     * Test method to verify if Flimsi is displayed in reserve.
     */
    @Test
    public void ChampionInReserveFlimsiDisplayed() {
        String result = game.getReserve();
        String[] xx = {"Flimsi"};
        boolean actual = containsText(result, xx);
        assertTrue(actual);
    }

    //Why were those chosen? You can add more but is it worth it ?
}
