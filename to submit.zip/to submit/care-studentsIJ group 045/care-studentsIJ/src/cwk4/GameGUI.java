package cwk4;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.Serializable;
import java.util.*;

/**
 * GameGUI provides a graphical user interface for the game.
 * It allows interaction with the game through buttons and menus.
 *
 * @author A.A.Marczyk
 * @version 20/01/24
 */
public class GameGUI
{
    private CARE gp = new Tournament("Fred");
    private JFrame myFrame = new JFrame("Game GUI");
    private JTextArea listing = new JTextArea();
    private JLabel codeLabel = new JLabel ();
    private JButton meetBtn = new JButton("Meet Challenge");
    private JButton viewBtn = new JButton("View State");
    private JButton clearBtn = new JButton("Clear");
    private JButton quitBtn = new JButton("Quit");
    private JPanel eastPanel = new JPanel();

    /**
     * The main method to launch the GameGUI.
     *
     * @param args command line arguments
     */
    public static void main(String[] args)
    {
        new GameGUI();
    }

    /**
     * Constructs the GameGUI.
     */
    public GameGUI()
    {
        makeFrame();
        makeMenuBar(myFrame);
    }


    /**
     * Create the Swing frame and its content.
     */
    private void makeFrame()
    {
        myFrame.setLayout(new BorderLayout());
        myFrame.add(listing,BorderLayout.CENTER);
        listing.setVisible(false);
        myFrame.add(eastPanel, BorderLayout.EAST);
        // set panel layout and add components
        eastPanel.setLayout(new GridLayout(5,1));
        eastPanel.add(meetBtn);
        eastPanel.add(clearBtn);
        eastPanel.add(quitBtn);
        eastPanel.add(viewBtn);

        clearBtn.addActionListener(new ClearBtnHandler());
        meetBtn.addActionListener(new MeetBtnHandler());
        quitBtn.addActionListener(new QuitBtnHandler());
        viewBtn.addActionListener(new ViewStateHandler());  // View state "Button"

        meetBtn.setVisible(true);
        clearBtn.setVisible(true);
        quitBtn.setVisible(true);
        viewBtn.setVisible(true);  // Set it to visible
        // building is done - arrange the components and show
        myFrame.pack();
        myFrame.setVisible(true);
    }


    // Implement action listener for "View State" button
    private class ViewStateHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            listing.setVisible(true);
            String gameState = gp.toString();
            listing.setText(gameState);
        }
    }

    /**
     * Create the main frame's menu bar.
     */
    private void makeMenuBar(JFrame frame)
    {
        JMenuBar menubar = new JMenuBar();
        frame.setJMenuBar(menubar);

        // create the File menu
        JMenu championMenu = new JMenu("Champions");
        menubar.add(championMenu);

        JMenuItem listChampionItem = new JMenuItem("List Champions in reserve");
        listChampionItem.addActionListener(new ListReserveHandler());
        championMenu.add(listChampionItem);

        JMenuItem listTeamItem = new JMenuItem("List Team");   // lists the details of champions in the vizier's team
        listTeamItem.addActionListener(new ListTeamHandler());
        championMenu.add(listTeamItem);

        JMenuItem viewChampion = new JMenuItem("View a Champion");
        viewChampion.addActionListener(new ViewChampionHandler());
        championMenu.add(viewChampion);


        JMenuItem enterChampion = new JMenuItem("Enter Champion");
        enterChampion.addActionListener(new EnterChampionHandler());
        championMenu.add(enterChampion);


        JMenu challengesMenu = new JMenu("Challenges");
        menubar.add(challengesMenu);


        JMenuItem listAllChallenges = new JMenuItem("List all challenges: ");
        listAllChallenges.addActionListener(new listAllChallengesHandler());
        challengesMenu.add(listAllChallenges);


    }

    private class listAllChallengesHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            listing.setVisible(true);
            String challenges  = gp.getAllChallenges();
            listing.setText(challenges);
        }
    }




    //  action listener for "Enter Champion" menu item
    private class EnterChampionHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String championName = JOptionPane.showInputDialog(myFrame, "Enter the name of the champion:");
            int xx = gp.enterChampion(championName);

            String message =" ";
            switch (xx) {
                case 0:
                    message = "Champion entered successfully.";
                    break;
                case 1:
                    message = "Champion is not in reserve.";
                    break;
                case 2:
                    message = "Not enough money in the treasury.";
                    break;
                case -1:
                    message = "No such champion.";
                    break;
            }

            JOptionPane.showMessageDialog(myFrame, message);
        }
    }


    //  action listener for "View Champion" menu item
    private class ViewChampionHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String championName = JOptionPane.showInputDialog(myFrame, "Enter the name of the champion:");
            String championDetails = gp.getChampionDetails(championName);

            if (championDetails != null) {
                JOptionPane.showMessageDialog(myFrame, championDetails, "Champion Details", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(myFrame, "Champion not found!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Action Listener added here
    private class ListTeamHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            listing.setVisible(true);
            String teamDetails = gp.getTeam();
            listing.setText(teamDetails);
        }
    }
    private class ListReserveHandler implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            listing.setVisible(true);
            String xx = gp.getReserve();
            listing.setText(xx);
        }
    }


    private class ClearBtnHandler implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            listing.setText(" ");
        }
    }

    private class MeetBtnHandler implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            int result = -1;
            String answer = "no such challenge";
            String inputValue = JOptionPane.showInputDialog("Challenge number ?: ");
            int num = Integer.parseInt(inputValue);
            result = gp.meetChallenge(num);
            switch (result)
            {
                case 0:answer = "challenge won by champion"; break;
                case 1:answer = "challenge lost on skills, champion disqualified";break;
                case 2:answer = "challenge lost as no suitable champion is available";break;
                case 3:answer = "challenge lost and vizier completely defeated";break;
            }

            JOptionPane.showMessageDialog(myFrame,answer);
        }
    }

    private class QuitBtnHandler implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            int answer = JOptionPane.showConfirmDialog(myFrame,
                    "Are you sure you want to quit?","Finish",
                    JOptionPane.YES_NO_OPTION);
            // closes the application
            if (answer == JOptionPane.YES_OPTION)
            {
                System.exit(0); //closes the application
            }
        }
    }

}
