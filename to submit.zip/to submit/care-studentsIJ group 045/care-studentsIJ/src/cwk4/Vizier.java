package cwk4;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Represents a vizier who manages champions and treasury.
 */
public class Vizier implements Serializable {
    private final String name; // The name of the vizier.
    private int treasury = 1000; // The amount of treasury the vizier possesses.
    private ArrayList<Champion> team = new ArrayList<Champion>(); // The list of champions in the vizier's team.
    private boolean hasChampions; // Indicates if the vizier has champions in their team.
    private boolean isTreasuryInDebt; // Indicates if the vizier's treasury is in debt.

    /**
     * Constructor for the Vizier class.
     *
     * @param name The name of the vizier.
     */
    public Vizier(String name) {
        this.name = name;
        hasChampions = false;
        isTreasuryInDebt = false;
    }

    /**
     * Retrieves the current treasury amount of the vizier.
     *
     * @return The treasury amount.
     */
    public int getTreasury() {
        return treasury;
    }

    /**
     * Adds a reward to the vizier's treasury.
     *
     * @param num The amount of reward to add.
     */
    public void addReward(int num) {
        this.treasury += num;
    }

    /**
     * Pays a reward from the vizier's treasury.
     *
     * @param num The amount of reward to pay.
     */
    public void payReward(int num) {
        this.treasury -= num;
    }

    /**
     * Retrieves the name of the vizier.
     *
     * @return The name of the vizier.
     */
    public String getVizierName() {
        return name;
    }




    /**
     * Retrieves the details of a specific champion in the vizier's team.
     *
     * @param champ The champion whose details are to be retrieved.
     * @return The details of the champion.
     */
    public String getChampion(Champion champ) {
        String s = "";
        for (Champion champion : team) {
            s += champion.toString();
        }
        return s;
    }

    /**
     * Retrieves the details of all champions in the vizier's team.
     *
     * @return The details of all champions in the team.
     */
    public String getTeam() {
        String s = "";
        for (Champion champion : team) {
            s += "\n" + champion.toString() + "\n";
        }
        if(s.equals("")){
            s = "No champions.";
        }
        return s;
    }

    /**
     * Checks if the vizier's treasury is in debt.
     *
     * @return True if the treasury is in debt, false otherwise.
     */
    public boolean isTreasuryInDebt() {
        return treasury < 0;
    }

    /**
     * Adds a champion to the vizier's team.
     *
     * @param c The champion to add.
     */
    public void addChampion(Champion c) {
        team.add(c);
    }

    /**
     * Removes a champion from the vizier's team and compensates half of their entry fee to the treasury.
     *
     * @param c The champion to remove.
     */
    public void removeChampion(Champion c) {
        team.remove(c);
        int gold = c.getEntryFee() / 2;
        treasury += gold;
    }

    /**
     * Retrieves all champions in the vizier's team.
     *
     * @return The list of champions in the team.
     */
    public ArrayList<Champion> getChamps() {
        return team;
    }

    /**
     * Provides a string representation of the vizier including their name, treasury amount,
     * presence of champions in the team, treasury debt status, and the list of champions in the team.
     *
     * @return String representation of the vizier.
     */
    public String toString() {
        return "Vizier name: " + getVizierName() +
                "\nTreasury: " + getTreasury() +
                "\nIs Vizier in debt? " + isTreasuryInDebt +
                "\n" +
                "\nVizier Team: " + "\n" + getTeam();
    }
}