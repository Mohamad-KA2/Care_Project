package cwk4;

import java.io.*;
import java.util.*;

/**
 * Command line interface for managing a tournament game.
 * Allows users to interact with the game by entering commands through the console.
 *
 * @author A.A.Marczyk
 * @version 10/03/2024
 */
public class GameUI {
    private Scanner myIn = new Scanner(System.in);

    /**
     * Runs the tournament game, allowing users to interact with it through the command line interface.
     */
    public void runGame() {
        Tournament tr;
        int choice;
        String vizierName;
        String output = "";
        int result = -1;
        try {
            // Takes Vizier name as input.
            System.out.println("Enter vizier's name");
            String s = myIn.nextLine();
            tr = new Tournament(s); // create
            // ******** Uncomment below when using challenges from files
            tr = new Tournament(s,"challengesAM.txt"); // alternative create task 3.5
            choice = 100;
            // Choice 0) Quit
            while (choice != 0) {
                choice = getMenuItem();
                // Choice 1) List Champions in Reserve
                if (choice == 1) {
                    System.out.println(tr.getReserve());
                    // Choice 2) List champions in vizier's team
                } else if (choice == 2) {
                    System.out.println(tr.getTeam());
                    // Choice 3) View a champion
                } else if (choice == 3) {
                    System.out.println("Enter Champion name");
                    String ref = (myIn.nextLine()).trim();
                    System.out.println(tr.getChampionDetails(ref));
                    // Choice 4) Enter champion into vizier's team
                } else if (choice == 4) {
                    System.out.println("\n" + tr.getReserve());
                    System.out.println("\nChoose the champion you would like to enter.");
                    String ref = (myIn.nextLine()).trim();
                    int answer = tr.enterChampion(ref);
                    switch (answer) {
                        // Champion has joined the team & been removed from reserve list
                        case 0:
                            System.out.println("Champion has joined your team successfully.");
                            break;
                        // Champion is not in the reserve list to be entered from
                        case 1:
                            System.out.println("That Champion is not in the reserve list.");
                            break;
                        // Vizier does not have the financing to hire this champion
                        case 2:
                            System.out.println("You do not have enough gulden in your treasury.");
                            break;
                        // The champion entered does not exist within the game
                        default:
                            System.out.print("That champion does not exist.");
                            break;
                    }
                    // Display all champions & then user chooses which champion they want to meet
                } else if (choice == 5) {
                    System.out.println("************ Available Challenges ********");
                    System.out.println("\n" + tr.getAllChallenges());
                    System.out.println("\nChoose the challenge you would like to meet.");
                    int ref = myIn.nextInt();
                    int answer = tr.meetChallenge(ref);
                    switch (answer) {
                        // Applicable champion has been selected, challenge has been won (Reward put into Vizier's treasury)
                        case 0:
                            System.out.println("Challenge won by champion.");
                            break;
                        // Applicable champion type has been selected, however the challenge has been lost due to not enough skill level
                        case 1:
                            System.out.println("Challenge lost on skills.");
                            break;
                        // Challenge has been lost as the Vizier does not have a champion with the correct type
                        case 2:
                            System.out.println("Challenge lost as no suitable champion available.");
                            break;
                        // Challenge has been lost, the treasury has been depleted/in debt and their team has been disqualified. Game over!
                        case 3:
                            System.out.println("Challenge is lost and rare Earth completely defeated.");
                            break;
                        // The challenge that is trying to be met does not exist
                        default:
                            System.out.println("No such challenge.");
                            break;
                    }
                    // Choice 6) Retire a champion
                } else if (choice == 6) {
                    System.out.println("\n" + tr.getTeam());
                    System.out.println("Who would you like to retire?");
                    String ref = (myIn.nextLine()).trim();
                    int answer = tr.retireChampion(ref);
                    switch (answer) {
                        // Champion has been sent back to reserves, half of their purchase price has been refunded to the treasury
                        case 0:
                            System.out.println("Champion has been retired to reserves.");
                            break;
                        // Champion is already disqualified, hence they cannot be retired to reserves
                        case 1:
                            System.out.println("Champion cannot be retired as they are disqualified.");
                            break;
                        // Champion is not part of the vizier's team, hence they cannot be retired
                        case 2:
                            System.out.println("Champion cannot be retired as they are not part of your team.");
                            break;
                        // The input champion does not exist, hence it cannot be retired
                        default:
                            System.out.println("That champion does not exist.");
                            break;
                    }
                    // View the game state -- (Reserve List, Vizier's team, Treasury amount & all challenges)
                } else if (choice == 7) {
                    System.out.println("============= CURRENT GAME STATE =============");
                    System.out.println("\n" + tr.toString());
                    // See all challenges within the challenge list
                } else if (choice == 8) {
                    System.out.println(tr.getAllChallenges());
                    // Save the state of the game into another file
                } else if (choice == 9) // Task 3.5 only
                {
                    System.out.println("Write to file");
                    System.out.println("Enter file name");
                    String filename = myIn.nextLine();
                    tr.saveGame(filename);
                    // Load the state of the game from another file
                } else if (choice == 10) // Task 3.5 only
                {
                    System.out.println("Restore from file");
                    System.out.println("Enter file name");
                    String filename = myIn.nextLine();
                    Tournament tr2 = tr.loadGame(filename);
                    if (tr2 != null) {
                        System.out.println(tr2.toString());
                        tr = tr2;
                    } else {
                        System.out.println("No such file");
                    }
                }
            }
        } catch (IOException e) {
            System.out.println(e);
        }
        System.out.println("Thank-you");
    }

    /**
     * Displays the main menu and prompts the user for their choice.
     *
     * @return The user's menu choice.
     * @throws IOException If an I/O error occurs.
     */
    private int getMenuItem() throws IOException {
        int choice = 100;
        System.out.println("\nMain Menu");
        System.out.println("0. Quit");
        System.out.println("1. List champions in reserve");
        System.out.println("2. List champions in viziers team");
        System.out.println("3. View a champion");
        System.out.println("4. Enter champion into vizier's team");
        System.out.println("5. Meet a challenge");
        System.out.println("6. Retire a champion");
        System.out.println("7. View game state");
        System.out.println("8. See all challenges");
        System.out.println("9. Save this game");
        System.out.println("10. Load this game");


        while (choice < 0 || choice > 10) {
            System.out.println("Enter the number of your choice");
            choice = myIn.nextInt();
        }
        myIn.nextLine();
        return choice;
    }

    /**
     * Converts the result of a challenge into a readable string.
     *
     * @param res The result of the challenge.
     * @return A string describing the result of the challenge.
     */
    private String processChallengeResult(int res) {

        String out;
        if (res == 0) {
            out = "Challenge won";
        } else if (res == 1) {
            out = "Challenge lost on skill level";
        } else if (res == 2) {
            out = "Challenge lost as no champion available";
        } else if (res == 3) {
            out = "Challenge lost with no further resources. You lose the game ";
        } else if (res == -1) {
            out = "No such challenge";
        } else {
            out = "No such result";
        }
        return out;
    }
    public static void main(String[] args){
        new GameUI().runGame();
    }
}