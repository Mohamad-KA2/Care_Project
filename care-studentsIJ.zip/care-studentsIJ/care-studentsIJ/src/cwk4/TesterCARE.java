//package cwk4;
//
///**
// * Write a description of class TesterCARE here.
// *
// * @author (your name)
// * @version (a version number or a date)
// */
//public class TesterCARE
//{
//    public static void main(String[] args)
//    {
//        Dragon gary = new Dragon("Gary", true);
//        Dragon barry = new Dragon("Barry", false);
//        Vizier me = new Vizier("Zorb");
//        me.addChampion(gary);
//        me.addChampion(barry);
//        //System.out.println(me.toString());
//
//        for(Champion temp: me.getChamps()){
//            if (temp.getSkillLvl() > 8){
//                System.out.println(temp);}
//        }
//    }
//
//    public void testChampions(){
//    Dragon gary = new Dragon("Gary", true);
//    //System.out.println(gary.toString());
//
//    Dragon barry = new Dragon("Barry", false);
//    //System.out.println(barry.toString());
//
//    Wizard mary = new Wizard("Mary", true, 4, "Levitation");
//    //System.out.println(mary.toString());
//
//    Wizard larry = new Wizard("Larry", false, 2, "Transmutation");
//    //System.out.println(larry.toString());
//
//    Warrior terry = new Warrior("Terry", 2, "Bucket");
//    //System.out.println(terry.toString());
//
//    Warrior jerry = new Warrior("Jerry", 5, "Mop");
//    //System.out.println(jerry.toString());
//}
//}
//
